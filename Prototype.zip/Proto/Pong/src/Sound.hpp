#ifndef SOUND_HPP_
#define SOUND_HPP_

#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Sound{

private:
  
  sf::SoundBuffer _buffer;
  sf::Sound _sound;
  int _volume=10;

public:

  Sound(std::string fileSoundBuffer);
  Sound();
  void play();
  void pause();
  void stop();
  void loop();
  
  int getVolume()const;
  void setVolume(int v); 
};

#endif
