#ifndef GESTIONCOLLISION_HPP_
#define GESTIONCOLLISION_HPP_

#include <SFML/Graphics.hpp>
#include "Ball.hpp"
#include "Bar.hpp"
#include "Sound.hpp"
#include <string>

class GestionCollision{
private:
  Ball & _ball;
  Bar & _bar1;
  Bar & _bar2;
  int _mov;
  Sound _sound;
  sf::Vector2f _windowSize;

  
public:

  GestionCollision(Ball & ball, Bar & bar1, Bar & bar2, Sound sound, sf::Vector2f windowSize);

  void GestionCollisionX();
  void GestionCollisionY();


  void volume_down();
  void volume_haut();
};

bool Colli_sion(const sf::IntRect &a, const sf::IntRect &b);

#endif
