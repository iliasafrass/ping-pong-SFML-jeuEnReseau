#ifndef SCORE_HPP_
#define SCORE_HPP_

#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>


class Score{

private:

int _score; // le score du joueur
  int _size; // la taille du score
  sf::Text _text; // texte correspendant au score 
  sf::Font _font; // font du score
  sf::Color _color; // couleur du score
  sf::Vector2f _position; // position du score sur l'écran
public:
 
public:
  //Constructeur de la classe Score
  Score(int size,std::string font,sf::Color color,sf::Vector2f position);
  //Getters
  int getScore()const;
  sf::Text getText()const;
  //Setters
  void setFont(sf::Font font);
  void setPosition(sf::Vector2f ps);
  void setScore(int score);
  //Convertir le score de int en sf::Text et le stocker dans l'attribut _text
  void scoreToText(int score);
};


#endif
