#ifndef BAR_HPP_
#define BAR_HPP_

#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <string>
#include <iostream>
#include "Sound.hpp"

class Bar{
private:
  sf::Texture _image; // texture de la bar
  sf::Sprite _sprite; // le sprite de la bar
  sf::Vector2f _position; // position de la bar
  sf::IpAddress _ipAddress; // adresse ip du joueur
  int _width;
  int _height; // hauteur de la bar
  int _speed; // vitesse de la bar
  Sound _sound; // son lors du mouvement de la bar
public:
  //Constructeur
  Bar(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int width, int height,int speed,Sound sound);
  //Déplacement des bars
  void moveUp();
  void moveDown();
  //Getters
  sf::Sprite getSprite();
  sf::IntRect getBoundingBox()const;
  sf::IpAddress getIpAddress()const;
  //Gérer le volume du son
  void baisserVolume();
  void augmenterVolume();
  //Met à jour la position de la Bar
  void setPosition(double y);

};

#endif
