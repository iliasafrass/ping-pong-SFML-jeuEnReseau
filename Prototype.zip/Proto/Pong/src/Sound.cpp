#include "Sound.hpp"
#include <iostream>

Sound::Sound(std::string fileSoundBuffer)
{
  if(!_buffer.loadFromFile(fileSoundBuffer)){
    std::cout<<"Error : problème de son"<<std::endl;
  }
  else
    {
      _sound.setBuffer(_buffer);
      _sound.setVolume(_volume);
    }
}

Sound::Sound(){}

void Sound::play(){
  _sound.play();
}

void Sound::pause(){
  _sound.pause();
}

void Sound::stop(){
  _sound.stop();
}

int Sound::getVolume()const{
  return _volume;
}

void Sound::setVolume(int v){
  _volume=v;
  _sound.setVolume(v);
}

void Sound::loop(){
  _sound.setLoop(true);
}
