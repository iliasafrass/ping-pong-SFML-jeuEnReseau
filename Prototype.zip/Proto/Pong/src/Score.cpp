#include "Score.hpp"


Score::Score(int size,std::string font,sf::Color color,sf::Vector2f position):_score(0),_size(size),_color(color),_position(position){
  //chargement du font
  if(!_font.loadFromFile(font)){
    //echec du chargement
    std::cout<<"Error : problem de telechargemenet de text"<<std::endl;
  }
  else {
    //reussite du chargement
    _text.setStyle(sf::Text::Regular); 
    _text.setCharacterSize(size);
    _text.setFont(_font);
    _text.setColor(color);
    _text.setPosition(_position);
  }
}

sf::Text Score::getText()const{
  return _text;
}

int Score::getScore()const{
  return _score;
}

void Score::setScore(int score){
  _score=score;
}

void Score::setFont(sf::Font font){
  _text.setFont(font);
}

void Score::setPosition(sf::Vector2f ps){
  _text.setPosition(ps);
}

void Score::scoreToText(int score){
   _text.setString(std::to_string(score));
}
