#include <iostream>
#include "Server.hpp"
//chemin de la feuille sprite 
const std::string sprite_chemin =  "barre_22.png";

//taille de l'ecran
const int ecran_hat = 800;
const int ecran_lar = 600;
const sf::Vector2f window_size(ecran_hat,ecran_lar);

//taille de la balle
const int ball_size = 12;

//la vitesse de la balle 
int BALL_SPEED = 2;

//balle initialement centré
const sf::Vector2f pos_ball(window_size.x/2 - ball_size/2 ,window_size.y/3 - ball_size/2);

//taille des barres
const int bar_lar = 12;
const int bar_haut = 45;

//position des barres
const sf::Vector2f pos_bar1(0 ,window_size.y/2 - bar_haut/2);
const sf::Vector2f pos_bar2(window_size.x-bar_haut/3, window_size.y/2 - bar_haut/2);

// les sous rectangles(x,y,z,f) located at (x,y) with a size of z*f
//(0,0,l,h)
const sf::IntRect Ball_subrect(100,100,20,20);
const sf::IntRect Bar1_subrect(1,0,18,68);
const sf::IntRect Bar2_subrect(1,0,18,68);

int main()
{
  std::cout<<"Local host:"<<sf::IpAddress::LocalHost<<"\n"
	   <<"Local: "<<sf::IpAddress::getLocalAddress()<<"\n";
  
  std::cout<<"\n";

  unsigned short port;
  std::cout<<"What port? ";
  std::cin>>port;
  std::cout<<"\n";

  Sound sonJeu("jeu.wav");
  Ball ball("ball.png", Ball_subrect, pos_ball, ball_size, BALL_SPEED,sonJeu);
  sf::Sprite _sprite =ball.getSprite();
  _sprite.setScale(3.0f , 0.1f);
  Sound sonBar("barr.WAV");
  Bar barre1(sprite_chemin, Bar1_subrect, pos_bar1, bar_lar, bar_haut,20,sonBar);
  Bar barre2(sprite_chemin, Bar2_subrect, pos_bar2, bar_lar, bar_haut,20,sonBar);
  
  Server server(port,ball, barre1, barre2, window_size);
  server.run();
  std::cin.get();

}
