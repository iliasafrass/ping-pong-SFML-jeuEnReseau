#ifndef BAR_HPP_
#define BAR_HPP_

#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>
#include "Sound.hpp"

class Bar{
private:
  sf::Texture _image;
  sf::Sprite _sprite;
  sf::Vector2f _position;
  
  int _width;
  int _height;
  int _speed;
  Sound _sound;

public:
  Bar();
  Bar(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int width, int height,int speed,Sound sound);
  void Move_up();
  void Move_down();
  sf::Sprite getSprite();
  sf::IntRect getBoundingBox()const;
  

  void volume_down();
  void volume_haut();
  void setPosition(double y);

};

#endif
