#include "Score.hpp"



Score::Score(int joueur,int size,sf::Vector2f pos_score,std::string filefont,sf::Color color):
  _scor(0),_joueur(joueur),_size(size),_pos_score(pos_score),_color(color)
{
  if(!_font.loadFromFile(filefont)){
    std::cout<<"Error : problem de telechargemenet de text"<<std::endl;
  }
  else {
    _text.setStyle(sf::Text::Regular); 
    _text.setCharacterSize(size);
    _text.setFont(_font);
    _text.setColor(color);
    _text.setPosition(pos_score);
   
  }
}

sf::Text Score::getText(){
  return _text;
}

void Score::setScore(int score){
  _scor=score;
}

void Score::affScore(int n){
  _text.setString(std::to_string(n));
}

void Score::setFont(sf::Font font){
  _text.setFont(font);
}

void Score::Move_text(sf::Vector2f st){
  _text.move(st);
}

void Score::setPosition(sf::Vector2f st){
  _text.setPosition(st);
}

int Score::getScore(){
  return _scor;
}
