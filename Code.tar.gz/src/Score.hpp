#ifndef SCORE_HPP_
#define SCORE_HPP_

#include <SFML/Graphics.hpp>
#include <string>
#include <iostream>


class Score{

private:

  int _scor;
  int _joueur;
  int _size;
  sf::Text _text;
  sf::Font _font;
  sf::Color _color;
  sf::Vector2f _pos_score;
  
public:

  Score(int joueur,int size,sf::Vector2f pos_score,std::string font,sf::Color color);
  void setScore(int score);
  int getScore();
  void setFont(sf::Font font);
  void Move_text(sf::Vector2f st);
  void setPosition(sf::Vector2f st);
  sf::Text getText();
  void affScore(int n);
};


#endif
