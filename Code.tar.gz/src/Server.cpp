#include "Server.hpp"



Server::Server(unsigned short port,Ball & ball, Bar & bar1, Bar & bar2, sf::Vector2f windowSize):
  _ball(ball),_bar1(bar1),_bar2(bar2),_windowSize(windowSize)
{
  listner.listen(port);
  listner.setBlocking(false);
}


Server::~Server()
{
}

void Server::handlePackets()
{
  //handle incoming data
  for(Clients::iterator it=clients.begin(); it!=clients.end();)
    {
      sf::Packet packet;
      sf::Socket::Status status=it->first->receive(packet);
    
      switch (status)
	{
	case sf::Socket::Done:
	  PacketType type;
	  packet>>type;
	  if(type==INITIAL_NAME_DATA)
	    {
	      //store the name
	      packet>>it->second;
	      std::cout<<it->second<<" has joined\n";
	      broadCast(INITIAL_NAME_DATA, it->second+" has joined\n");
	    }
	  else if(type==POS_BALL)
	    {
	      sf::Packet packetEnvoye;
	      packetEnvoye << "Pos_ball" << _ball.getBoundingBox().left << _ball.getBoundingBox().top;
	      	sf::Thread thread([&]()
	{
	      it->first->send(packetEnvoye);
	});
	thread.launch();
	      _ball.moveX();
	      GestionCollisionX();
	      _ball.moveY();
	      GestionCollisionY();	      
	    }
	   else if(type == POS_BAR1){
	     std::string posBar1;
	     packet >> posBar1;
	     int a = std::atoi(posBar1.c_str());
	     _bar1.setPosition(a);
	     for(Clients::iterator it2=clients.begin(); it2!=clients.end();++it2){
	       if(it->second.compare(it2->second) != 0){
		  sf::Packet packetEnvoye;
		  packetEnvoye << "Pos_bar" << a;
		  sf::Thread thread1([&]()
				    {
	      
				      it2->first->send(packetEnvoye);
				    });
	thread1.launch();
	      
	       }
	     }
	   } else if(type == POS_BAR2){
	     std::string posBar2;
	     packet >> posBar2;
	     int b = std::atoi(posBar2.c_str());
	     _bar2.setPosition(b);
	     for(Clients::iterator it2=clients.begin(); it2!=clients.end();++it2){
	     if(it->second.compare(it2->second) != 0){
	      	  sf::Packet packetEnvoye;
	      	  packetEnvoye << "Pos_bar" << b;
		  sf::Thread thread2([&]()
				    {
	      
				      it2->first->send(packetEnvoye);
				    });
	thread2.launch();
	        }
	      }
	   }
	  
	  ++it;
	  break;

	case sf::Socket::Disconnected:
	  std::cout<<it->second<<" has been disconnected\n";
	  broadCast(SERVER_MSG, it->second+" has been disconnected\n");
	  it=clients.erase(it);
	  break;

	default:
	  ++it;
	}
    }
}

void Server::broadCast(PacketType type, const std::string & msg)
{ 
  for(Clients::iterator it=clients.begin(); it!=clients.end(); ++it)
    {
      sf::Packet pack;
      pack<<type<<msg;
	it->first->send(pack);
    }
}

void Server::run()
{ 
  sf::TcpSocket * nextClient=nullptr;
  while(1)
    {
      //Handle newcoming clients
      if(nextClient==nullptr)
	{
	  nextClient=new sf::TcpSocket;
	  nextClient->setBlocking(false);
	}
      if(listner.accept(*nextClient) == sf::Socket::Done && clients.size() <= 2)
	{
	  
	  clients.insert(std::make_pair(nextClient,""));
	  nextClient=nullptr;
	}
      handlePackets();
      //std::cout<<"!\n";	
    }
}

void Server::GestionCollisionX(){
  sf::IntRect ballRect = _ball.getBoundingBox();
  sf::IntRect bar1Rect = _bar1.getBoundingBox();
  sf::IntRect bar2Rect = _bar2.getBoundingBox();

  
  
   if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect) || ballRect.left < 0 || (ballRect.left+ ballRect.width) > _windowSize.x){

    _ball.inverserDX();
    _ball.moveX();
  }
  }

void Server::GestionCollisionY(){
  sf::IntRect ballRect = _ball.getBoundingBox();
  sf::IntRect bar1Rect = _bar1.getBoundingBox();
  sf::IntRect bar2Rect = _bar2.getBoundingBox();
  
 if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect) || ballRect.top < 0 || (ballRect.top +ballRect.height) > _windowSize.y){
    _ball.inverserDY();
    _ball.moveY();
  }
}

Ball& Server::getBall(){
  return _ball;
}
