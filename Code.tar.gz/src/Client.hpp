#pragma once
#include "SFML/Network.hpp"
#include "PacketType.hpp"
#include <iostream>
#include "Ball.hpp"
#include "Bar.hpp"
#include <sstream>
class Client
{
private:
  std::string name;
  sf::TcpSocket me;
  int _id;
public:
  Client(const std::string & name,int id);
  ~Client();

  int getId();
  sf::Socket::Status connect(const sf::IpAddress & IP, unsigned short port);
  sf::Socket::Status send (PacketType type, const std::string & name);  
  sf::Socket::Status receive(Ball & ball);
  sf::Socket::Status receive( Bar &bar);
  
};

