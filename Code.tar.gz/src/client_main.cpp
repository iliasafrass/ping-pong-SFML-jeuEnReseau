#include <iostream>
#include <unistd.h>
#include "Client.hpp"
#include "PacketType.hpp"
#include <SFML/Graphics.hpp>
#include "Ball.hpp"
#include "Bar.hpp"
#include "Score.hpp"
#include "Sound.hpp"
#include <string>
//chemin de la feuille sprite 
const std::string sprite_chemin =  "barre_22.png";

//taille de l'ecran
const int ecran_hat = 800;
const int ecran_lar = 600;
const sf::Vector2f window_size(ecran_hat,ecran_lar);

//taille de la balle
const int ball_size = 12;

//la vitesse de la balle 
int BALL_SPEED = 2;

//balle initialement centré
const sf::Vector2f pos_ball(window_size.x/2 - ball_size/2 ,window_size.y/3 - ball_size/2);

//taille des barres
const int bar_lar = 12;
const int bar_haut = 45;

//position des barres
const sf::Vector2f pos_bar1(0 ,window_size.y/2 - bar_haut/2);
const sf::Vector2f pos_bar2(window_size.x-bar_haut/3, window_size.y/2 - bar_haut/2);

// les sous rectangles(x,y,z,f) located at (x,y) with a size of z*f
//(0,0,l,h)
const sf::IntRect Ball_subrect(100,100,20,20);
const sf::IntRect Bar1_subrect(1,0,18,68);
const sf::IntRect Bar2_subrect(1,0,18,68);

//la position de text
const sf::Vector2f pos_score(40,30);
const sf::Vector2f pos_score2(730,30);

int main()
{
  std::string name;
  std::cout<<"What's your name: ";
  std::getline(std::cin, name);
  std::cout<<"\n";

  int id;
  std::cout<<"What's your id: ";
  std::cin >> id;
  std::cout<<"\n";
  Client client(name,id);

  unsigned short port;
  std::cout<<"What port? ";
  std::cin>>port;
  std::cin.get();

  std::cout<<"saisir l'adresse du serveur :";
  std::string IP;
  std::getline(std::cin, IP);
	
  sf::Socket::Status status;
  status=client.connect(IP, port);
  if(status!=sf::Socket::Done)
    {
      std::cout<<"Sorry we couldn't connect\n";
      return -1;
    }
  
  client.send(INITIAL_NAME_DATA,name);
  /* Fenetre */

  sf::RenderWindow window(sf::VideoMode(window_size.x,window_size.y),"PONG",sf::Style::Close | sf::Style::Titlebar);
  
  window.setFramerateLimit(60);

  Sound sonJeu("jeu.wav");
  Ball ball("ball.png", Ball_subrect, pos_ball, ball_size, BALL_SPEED,sonJeu);

  sf::Sprite _sprite =ball.getSprite();
  _sprite.setScale(3.0f , 0.1f);

  Sound sonBar("barr.WAV");
  Bar barre1(sprite_chemin, Bar1_subrect, pos_bar1, bar_lar, bar_haut,20,sonBar);
  Bar barre2(sprite_chemin, Bar2_subrect, pos_bar2, bar_lar, bar_haut,20,sonBar);
  sf::Color color(42,183,229);
  Score _score(1,60,pos_score,"fonts3.ttf",color);
  Score _score2(2,60,pos_score2,"fonts3.ttf",color);

  sf::Texture img;
  sf::Sprite background;
  
  if(!img.loadFromFile("back_22.png"))
    {
      std::cerr<<"erreur d'importer l'arrière plan"<<std::endl;
      return EXIT_FAILURE;//ON FERME LE PROGRAMME
    }
  else
    {
      background.setTexture(img);
    }
 
  sf::Vector2f scale = background.getScale();
  background.setScale(scale.x*1.5 , scale.y*1.5);
  //Boucle principale
  
  sf::Event event;
  while (window.isOpen())//boucle principale
    {

          
      std::string str;
      std::string str2;
      
      std::stringstream convert;
      convert << barre1.getBoundingBox().top;
      str = convert.str();

      std::stringstream convert2;
      convert2 << barre2.getBoundingBox().top;
      str2 = convert2.str();
      
      if(id % 2 != 0){
	sf::Thread thread([&]()
			  {
			    client.send(POS_BAR1,str);
			  });
	thread.launch();
	sf::Thread thread0([&]()
			   {
			     client.receive(barre2);
			   });
	thread0.launch();
      }
      else if(id % 2 == 0){
	sf::Thread thread1([&]()
			   {
			     client.send(POS_BAR2,str2);
	
			   });
	thread1.launch();
	sf::Thread thread11([&]()
			    {
			      client.receive(barre1);
			    });
	thread11.launch();
      }

      sf::Thread thread2([&]()
			 {
			   client.send(POS_BALL,"");
			 });
      thread2.launch();
	
      sf::Thread thread21([&]()
			  {
			    client.receive(ball);
			  });
      thread21.launch();
      
      while (window.pollEvent(event))// boucle des évenements
	if(event.type==sf::Event::Closed)
	  window.close();
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){
	window.close();
      }
      
      /* evenvement clavier */
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
	  //envoyer la position au serveur
	  if(client.getId() % 2 != 0){
	    if(barre1.getBoundingBox().top >0 )
	      barre1.Move_up();
	  }else{
	    if(barre2.getBoundingBox().top >0 )
	      barre2.Move_up(); 
	  }	  
	}
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Add)){
	//gest_col.volume_haut();
	ball.volume_haut();
	barre1.volume_haut();
	barre2.volume_haut();
      }

      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Subtract)){
	//gest_col.volume_down();
	ball.volume_down();
	barre1.volume_haut();
	barre2.volume_down();
      }

      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
	  if(client.getId() % 2 != 0){
	    if(barre1.getBoundingBox().top < ecran_lar-barre1.getBoundingBox().height*1.5)
	      barre1.Move_down();
	  }else{
	    if(barre2.getBoundingBox().top < ecran_lar-barre2.getBoundingBox().height*1.5)
	      barre2.Move_down();
	  }
	    
	}
      /* afficher text */
      if(ball.getBoundingBox().left <= 2 && !barre1.getBoundingBox().intersects(ball.getBoundingBox()))
      	{
	  
      	  int sc=_score.getScore();
       	  sc++;
       	  _score.setScore(sc);
        
       	}
      _score.affScore(_score.getScore()/4);


      if(ball.getBoundingBox().left+ball.getBoundingBox().width >= pos_bar2.x   && !barre2.getBoundingBox().intersects(ball.getBoundingBox()))
      	{
	 
      	  int sc2=_score2.getScore();
      	  sc2++;
      	  _score2.setScore(sc2);
      	}
      _score2.affScore(_score2.getScore()/16);
      ball.setSpeed(BALL_SPEED);

      // faire de l'affichage 
      window.clear();
      window.draw(background);
      window.draw(ball.getSprite());
      window.draw(barre1.getSprite());
      window.draw(barre2.getSprite());
      window.draw(_score.getText());
      window.draw(_score2.getText());
      
      window.display();
    }
  return EXIT_SUCCESS; 
  	
}
