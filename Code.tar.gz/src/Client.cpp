#include "Client.hpp"
#include "PacketType.hpp"
#include <iostream>

Client::Client(const std::string & name_,int id):name(name_),_id(id)
{
}


Client::~Client(void)
{
}

int Client::getId(){
  return _id;
}

sf::Socket::Status Client::connect(const sf::IpAddress & IP, unsigned short port)
{
  //connect to server
  sf::Socket::Status stat= me.connect(IP, port);
  me.setBlocking(false);
  return stat;
}


sf::Socket::Status Client::send (PacketType type, const std::string & name){
  sf::Packet packet;
  packet<<type<<name;
  return me.send(packet);
}


sf::Socket::Status Client::receive(Ball& ball)
{
  std::string  msg;
  sf::Packet packet;
  sf::Socket::Status status=me.receive(packet);
  int X,Y;
	
  if(status==sf::Socket::Done){
    if(packet>> msg >> X >> Y){
      if(msg == "Pos_ball"){
	ball.setPosition(sf::Vector2f(X,Y));
      }
    }
  }
  return status;
}


sf::Socket::Status Client::receive(Bar &bar)
{
  std::string  msg;
  sf::Packet packet;
  sf::Socket::Status status=me.receive(packet);
  int X;
	
  if(status==sf::Socket::Done){
    if(packet>> msg >> X){
      if(msg == "Pos_bar"){
      	bar.setPosition(X);
      }
    }
  }
  return status;
}
