#include "Bar.hpp"

Bar::Bar(){}


Bar::Bar(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int width, int height,int speed,Sound sound):_position(position),_width(width),_height(height),_speed(speed),_sound(sound)
{
  if(!_image.loadFromFile(cheminFichier))
    {    //si le chargement a echoué
      std::cerr << "erreur de chargement de l'image ! "<< cheminFichier <<std::endl;
    }
  else
    {//si le chargement a reussi
    
      _sprite.setTexture(_image);
      _sprite.setTextureRect(rect); // sous rectangle
      _sprite.setPosition(position);
    }  
}

void Bar::Move_up()
{
    _sound.play();
    _sprite.move(0,-4);
  
}

void Bar::Move_down()
{
    _sound.play();
    _sprite.move(0,4);
  
}

void Bar::setPosition(double y)
{
  //if( _pause == false)
  _sprite.setPosition(_position.x,y);
}


sf::Sprite Bar::getSprite()
{
  return _sprite;
}

sf::IntRect Bar::getBoundingBox()const
{

  sf::IntRect boundingBox;
  boundingBox.left = (int)_sprite.getPosition().x;
  boundingBox.width =  _width;
  boundingBox.top = (int)_sprite.getPosition().y;
  boundingBox.height = _height;

  return boundingBox;
}



void Bar::volume_haut(){
  int Volume =_sound.getVolume();
  if( Volume <=  100 ){
    Volume+=5;
    _sound.setVolume(Volume);
  }
}
void Bar::volume_down(){
  int Volume = _sound.getVolume();
  if( Volume >= 5 ){
    Volume-=5;
  _sound.setVolume(Volume);
  }
}
