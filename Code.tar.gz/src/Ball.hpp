#ifndef BALL_HPP_
#define BALL_HPP_
#include <SFML/Graphics.hpp>
#include <string>
#include<iostream>
#include "Sound.hpp"

class Ball{

private:
  sf::Texture _image;
  sf::Sprite _sprite;
  int _size;
  int _DX;
  int _DY;
  int _speed;

  Sound _sound;

public:
  Ball(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int size, int speed,Sound sound);
  void moveX();
  void moveY();
  void inverserDX();
  void inverserDY();
  void setPosition(sf::Vector2f position);


  void volume_down();
  void volume_haut();

  void setSpeed(int s);
  sf::Sprite getSprite();
  sf::IntRect getBoundingBox()const;
};


#endif
