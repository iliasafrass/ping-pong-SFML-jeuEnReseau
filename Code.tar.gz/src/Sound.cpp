#include "Sound.hpp"
#include <iostream>

Sound::Sound(std::string fileSounfBuffer)
{
  if(!_buffer.loadFromFile(fileSounfBuffer)){
    std::cout<<"Error : problem de son"<<std::endl;
  }
  else
    {
      _sound.setBuffer(_buffer);
      _sound.setVolume(_volume);
    }
}

Sound::Sound(){}

void Sound::play(){
  _sound.play();
}

void Sound::pause(){
  _sound.pause();
}

void Sound::stop(){
  _sound.stop();
}

int Sound::getVolume()const{
  return _volume;
}

void Sound::setVolume(int v){
  _volume=v;
  _sound.setVolume(v);
}

void Sound::Loop(){
  _sound.setLoop(true);
}
