#pragma once
#include <unordered_map>
#include "SFML/Network.hpp"
#include "PacketType.hpp"
#include <vector>
#include <iostream>
#include "Ball.hpp"
#include "Bar.hpp"
#include <sstream>
#include <string>

class Server
{
private:
  typedef std::unordered_map<sf::TcpSocket *, std::string> Clients;
  Clients clients;
  sf::TcpListener listner;
   Ball & _ball;
  Bar & _bar1;
  Bar & _bar2;
  sf::Vector2f _windowSize;
  
  void handlePackets();
  void broadCast(PacketType type, const std::string & msg);
public:
  Server(unsigned short port,Ball & ball, Bar & bar1, Bar & bar2, sf::Vector2f windowSize);
  ~Server();
  Ball& getBall();
  void GestionCollisionX();
  void GestionCollisionY();
  void run();
	
	
};

