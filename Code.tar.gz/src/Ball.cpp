#include "Ball.hpp"

Ball::Ball(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int size, int speed,Sound sound):
  _size(size),_DX(speed),_DY(speed),_speed(speed),_sound(sound){
  if(!_image.loadFromFile(cheminFichier)){    //si le chargement a echoué
     std::cerr << "erreur de chargement de l'image ! "<< cheminFichier <<std::endl;
  }else{//si le chargement a reussi
   
    _sprite.setTexture(_image);
    _sprite.setTextureRect(rect); // sous rectangle
    _sprite.setPosition(position);
    _sound.play();
    _sound.Loop();
  }  
}
void Ball::setPosition(sf::Vector2f position){
  _sprite.setPosition(position);
}

void Ball::setSpeed(int s){
  _speed = s;
}
void Ball::moveX()
{
 
  _sprite.move(_DX,0);

}
void Ball::moveY()
{
  
  _sprite.move(0,_DY);
}

void Ball::inverserDX(){
  
  _DX *= -1;//inversement de DX
}

void Ball::inverserDY(){
  
  _DY *= -1;//inversement de DY
}

sf::Sprite Ball::getSprite(){
  return _sprite;
}

sf::IntRect Ball::getBoundingBox()const{
  sf::IntRect boundingBox;
  boundingBox.left = (int)_sprite.getPosition().x;
  boundingBox.width =  _size;
  boundingBox.top = (int)_sprite.getPosition().y;
  boundingBox.height = _size ;
  return  boundingBox;
}

void Ball::volume_haut(){
  int Volume =_sound.getVolume();
  if( Volume <=  100 ){
    Volume+=5;
    _sound.setVolume(Volume);
  }
}
void Ball::volume_down(){
  int Volume = _sound.getVolume();
  if( Volume >= 5 ){
    Volume-=5;
  _sound.setVolume(Volume);
  }
}

