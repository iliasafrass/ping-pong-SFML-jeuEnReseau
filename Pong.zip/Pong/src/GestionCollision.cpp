
#include "GestionCollision.hpp"


GestionCollision::GestionCollision(Ball & ball, Bar & bar1, Bar & bar2,Sound sound, sf::Vector2f windowSize):
  _ball(ball),_bar1(bar1),_bar2(bar2),_sound(sound),_windowSize(windowSize)
{
  //_sound.play();
}



void GestionCollision::GestionCollisionX(){
  sf::IntRect ballRect = _ball.getBoundingBox();
  sf::IntRect bar1Rect = _bar1.getBoundingBox();
  sf::IntRect bar2Rect = _bar2.getBoundingBox();

  
  
   if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect) || ballRect.left < 0 || (ballRect.left+ ballRect.width) > _windowSize.x){

    _ball.inverserDX();
    _ball.moveX();
  }
  if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect)){
    _sound.play();
  }
}
void GestionCollision::GestionCollisionY(){

  sf::IntRect ballRect = _ball.getBoundingBox();
  sf::IntRect bar1Rect = _bar1.getBoundingBox();
  sf::IntRect bar2Rect = _bar2.getBoundingBox();

  
 if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect) || ballRect.top < 0 || (ballRect.top +ballRect.height) > _windowSize.y){


    _ball.inverserDY();
    _ball.moveY();
  }

  if(bar1Rect.intersects(ballRect) || bar2Rect.intersects(ballRect))
     _sound.play();
}

void GestionCollision::volume_haut(){
  int Volume =_sound.getVolume();
  if( Volume <=  100 ){
    Volume+=5;
    _sound.setVolume(Volume);
  }
}
void GestionCollision::volume_down(){
  int Volume = _sound.getVolume();
  if( Volume >= 5 ){
    Volume-=5;
    _sound.setVolume(Volume);
  }
}

