#define BOOST_TEST_MODULE MesTestsUnitaires
#include <boost/test/included/unit_test.hpp>

