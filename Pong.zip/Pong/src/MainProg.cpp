#include "GestionCollision.hpp"
#include "Score.hpp"
#include "Sound.hpp"

//chemin de la feuille sprite 
const std::string sprite_chemin =  "barre_22.png";

//taille de l'ecran
const int ecran_haut = 800;
const int ecran_lar = 600;
const sf::Vector2f window_size(ecran_haut,ecran_lar);

//taille de la balle
const int ball_size = 12;

//la vitesse de la balle 
 int BALL_SPEED = 2;

//balle initialement centré
const sf::Vector2f pos_ball(window_size.x/2 - ball_size/2 ,window_size.y/3 - ball_size/2);

//taille des barres

const int bar_lar = 12;
const int bar_haut = 45;


//position des barres
const sf::Vector2f pos_bar1(0 ,window_size.y/2 - bar_haut/2);
  
const sf::Vector2f pos_bar2(window_size.x-bar_haut/3, window_size.y/2 - bar_haut/2);

// les sous rectangles(x,y,z,f) located at (x,y) with a size of z*f
//(0,0,l,h)
const sf::IntRect Ball_subrect(100,100,20,20);
const sf::IntRect Bar1_subrect(1,0,18,68);
const sf::IntRect Bar2_subrect(1,0,18,68);

//la position de text
const sf::Vector2f pos_score(40,30);
const sf::Vector2f pos_score2(730,30);
int main(){  
  /* Fenetre */

  sf::RenderWindow window(sf::VideoMode(window_size.x,window_size.y),"PONG",sf::Style::Close | sf::Style::Titlebar);
  
  window.setFramerateLimit(60);

  Sound sonJeu("jeu.wav");
  Ball ball("ball_22.png", Ball_subrect, pos_ball, ball_size, BALL_SPEED,sonJeu);
  sf::Sprite _sprite =ball.getSprite();
  _sprite.setScale(3.0f , 0.1f);

  Sound sonBar("barr.WAV");
  Bar barre1(sprite_chemin, Bar1_subrect, pos_bar1, bar_lar, bar_haut,20,sonBar);
  Bar barre2(sprite_chemin, Bar2_subrect, pos_bar2, bar_lar, bar_haut,20,sonBar);
  sf::Color color(42,183,229);
  Score _score(60,"fonts3.ttf",color,pos_score);
  Score _score2(60,"fonts3.ttf",color,pos_score2);
 
  Sound sonColi("zik_col.wav");
  GestionCollision gest_col(ball, barre1, barre2,sonColi, window_size);
  sonJeu.pause();
  
  sf::Texture img;
  sf::Sprite background;
  
  if(!img.loadFromFile("back_22.png"))
    {
      std::cerr<<"erreur d'importer l'arrière plan"<<std::endl;
      return EXIT_FAILURE;//ON FERME LE PROGRAMME
    }
  else
    {
      background.setTexture(img);
    }
 
  sf::Vector2f scale = background.getScale();
  background.setScale(scale.x*1.5 , scale.y*1.5);
  //Boucle principale

  sf::Event event;
  while (window.isOpen())//boucle principale
    {
      while (window.pollEvent(event))// boucle des évenements
	{
	  switch(event.type)
	    {	    
	    case sf::Event::Closed :
	      window.close();
	      break;	      
	    default:
	      break;
	    }
	}
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){
	window.close();
      }
      
      /* evenvement clavier */
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
	{
	  if(barre1.getBoundingBox().top >0 )
	    barre1.moveUp();
	  
	}
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Add)){
	gest_col.volume_haut();
	ball.augmenterVolume();
	barre1.augmenterVolume();
	barre2.augmenterVolume();
      }

      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Subtract)){
	gest_col.volume_down();
	ball.baisserVolume();
	barre1.baisserVolume();
	barre2.baisserVolume();
      }

      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
	{
	  
	  if(barre1.getBoundingBox().top < ecran_lar-barre1.getBoundingBox().height*1.5)
	    barre1.moveDown();
	    
	}
	
     
      /* la position globale de la souris sur fenetre */
      sf::Vector2i globalPosition =sf::Mouse::getPosition(window);
	
      if( globalPosition.y > 0 && globalPosition.y < ecran_lar -barre2.getBoundingBox().height*1.5)
      	{
      	  barre2.setPosition(globalPosition.y);
      	}
	
	
      /* afficher text */
      if(ball.getBoundingBox().left <= 2 && !barre1.getBoundingBox().intersects(ball.getBoundingBox()))
      	{
	  
      	  int sc=_score.getScore();
       	  sc++;
       	  _score.setScore(sc);
        
       	}
      _score.scoreToText(_score.getScore()/4);


      if(ball.getBoundingBox().left+ball.getBoundingBox().width >= pos_bar2.x   && !barre2.getBoundingBox().intersects(ball.getBoundingBox()))
      	{
	 
      	  int sc2=_score2.getScore();
      	  sc2++;
      	  _score2.setScore(sc2);
      	}
     
      _score2.scoreToText(_score2.getScore()/16);
      /* faire de mouvement */
     
      ball.moveX();
      gest_col.GestionCollisionX();
      
      ball.moveY();
      gest_col.GestionCollisionY();
	
      
      // faire de l'affichage 
      window.clear();
      window.draw(background);
      window.draw(ball.getSprite());
      window.draw(barre1.getSprite());
      window.draw(barre2.getSprite());
      window.draw(_score.getText());
      window.draw(_score2.getText());
      
      window.display();
      
    }

  
  
  return EXIT_SUCCESS; 
  
}
