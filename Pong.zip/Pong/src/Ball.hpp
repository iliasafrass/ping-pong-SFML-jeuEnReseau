#ifndef BALL_HPP_
#define BALL_HPP_
#include <SFML/Graphics.hpp>
#include <string>
#include<iostream>
#include "Sound.hpp"

class Ball{

private:
  sf::Texture _image; // texture de la balle
  sf::Sprite _sprite; // sprite de la balle
  int _size; // taille de la balle
  int _DX; // déplacement de la balle sous l'axe X
  int _DY; // déplacement de la balle sous l'axe Y
  int _speed; // vitesse du déplacement de la balle 
  bool _pause = false; // mettre la balle en pause
  Sound _sound; // son du mouvement de la balle

public:
  //contructeur de la classe Ball
  Ball(const std::string & cheminFichier, sf::IntRect rect, sf::Vector2f position, int size, int speed,Sound sound);
  //mouvement de la balle sur la scène
  void moveX();
  void moveY();
  //changer le mouvement de la balle au sens inverse
  void inverserDX();
  void inverserDY();
  //met à jour la position de la balle
  void setPosition(sf::Vector2f position);
  //met la balle en pause
  void setPause(bool p);
  bool getPause()const;
  //gérer la balle
  void baisserVolume();
  void augmenterVolume();
  //getter de _sprite
  sf::Sprite getSprite();
  //récuperer un cadre de la balle
  sf::IntRect getBoundingBox()const;
};


#endif
